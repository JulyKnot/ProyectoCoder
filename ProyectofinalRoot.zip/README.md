# ProyectoCoder
Éste código pertenece a mi primer diseño web , preparado en base a mi emprendimiento de fotografía analogica , un laboratorio llamado Loki . 
Una tienda virtual con información sobre diferentes temas referidos a la fotografía y sus modos de verse dependiendo de quién sea el fotografo/a y sobre mi.
